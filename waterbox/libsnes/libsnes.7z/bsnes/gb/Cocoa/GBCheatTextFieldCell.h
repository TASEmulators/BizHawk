#import <Cocoa/Cocoa.h>

@interface GBCheatTextFieldCell : NSTextFieldCell
@property bool usesAddressFormat;
@end
