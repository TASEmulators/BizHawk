#import <AppKit/AppKit.h>
@implementation NSObject (MavericksCompat)
- (instancetype)initWithCoder:(NSCoder *)coder
{
    return [self init];
}
@end
