#import <Cocoa/Cocoa.h>

@interface GBImageCell : NSImageCell

@end
