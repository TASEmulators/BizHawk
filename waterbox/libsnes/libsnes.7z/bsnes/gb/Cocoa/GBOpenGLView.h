#import <Cocoa/Cocoa.h>
#import "GBGLShader.h"

@interface GBOpenGLView : NSOpenGLView
@property GBGLShader *shader;
@end
