#ifndef open_rom_h
#define open_rom_h

char *do_open_rom_dialog(void);

#endif /* open_rom_h */
