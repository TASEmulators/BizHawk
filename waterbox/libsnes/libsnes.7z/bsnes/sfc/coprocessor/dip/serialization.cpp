auto DIP::serialize(serializer& s) -> void {
  s.integer(value);
}
