#include <emulator/emulator.hpp>
#include <emulator/audio/audio.cpp>

namespace Emulator {

Platform* platform = nullptr;

}
